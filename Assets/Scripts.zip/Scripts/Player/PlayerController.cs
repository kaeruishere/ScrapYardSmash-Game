using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float speed = 5f;
    public float crouchSpeed = 2.5f;
    public float jumpHeight = 1.5f;
    public float gravity = -9.81f;

    [Header("Pickup System")]
    public Transform holdPoint;               // Elde duracağı nokta
    public float pickupRange = 3f;
    public float throwForce = 10f;
    public Vector3 pickupPos = new Vector3(0.15f, -0.2f, 0.4f);
    public Vector3 pickupRot = new Vector3(-15f, 90f, -20f);

    [Header("Held Object")]
    private GameObject heldObject;

    [Header("Crouch")]
    public float standHeight = 2f;
    public float crouchHeight = 1f;
    public float crouchSmooth = 10f;

    [Header("Weapon Management")]
    [SerializeField] private PhysicalWeapon currentWeapon;
    public bool isPerformingAttack = false;

    private Animator animator;
    private CharacterController cc;
    private Vector3 velocity;
    private bool isGrounded;
    private bool crouching;
    private float targetHeight;

    private float moveX;
    private float moveZ;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        animator = GetComponent<Animator>();

        targetHeight = standHeight;

        // Başlangıçta elde silah YOK
        currentWeapon = null;
    }

    void Update()
    {
        moveX = Input.GetAxisRaw("Horizontal");
        moveZ = Input.GetAxisRaw("Vertical");

        HandlePickup();     // E ile yerden alma
        HandleThrow();      // Sağ tık ile fırlatma

        HandleMovementAndAnimation();
        HandleJumpAndGravity();
        HandleCrouch();
        HandleAttackInput();

        ApplyMovement();
        WeaponCheck();
    }

    // ============================================================
    // PICKUP (E tuşu)
    // ============================================================

    void HandlePickup()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (heldObject == null)
                TryPickup();
            else
                DropObject();
        }
    }

    void TryPickup()
{
    Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
    RaycastHit hit;

    if (Physics.Raycast(ray, out hit, pickupRange))
    {
        if (hit.collider.CompareTag("Pickup") || hit.collider.CompareTag("Ball"))
        {
            heldObject = hit.collider.gameObject;

            Rigidbody rb = heldObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.isKinematic = true;
                rb.useGravity = false;
            }

            Collider col = heldObject.GetComponent<Collider>();
            if (col != null)
                col.enabled = false;

            // Elde konumlandır (ilk karede anlık pozisyon)
            heldObject.transform.SetParent(holdPoint);
            heldObject.transform.localPosition = new Vector3(0, 0, 0);
            heldObject.transform.localRotation = Quaternion.identity;

            // Yumuşak geçiş başlat
            StartCoroutine(SmoothEquip(heldObject));

            // PhysicalWeapon bağla
            PhysicalWeapon wc = heldObject.GetComponent<PhysicalWeapon>();
            currentWeapon = wc;
        }
    }
}


    // ============================================================
    // THROW (Sağ Tık)
    // ============================================================

    void HandleThrow()
    {
        if (Input.GetMouseButtonDown(1) && heldObject != null)
            ThrowObject();
    }

    void ThrowObject()
{
    Rigidbody rb = heldObject.GetComponent<Rigidbody>();
    Collider col = heldObject.GetComponent<Collider>();

    heldObject.transform.SetParent(null);

    if (col != null)
        col.enabled = true;

    if (rb != null)
    {
        rb.isKinematic = false;
        rb.useGravity = true;

        // Kamera yönü (dokunmuyoruz)
        Vector3 throwDir = Camera.main.transform.forward;

        // İstersen çok hafif bir denge verilebilir (isteğe bağlı):
        throwDir.y += 0.05f;  // sadece küçük bir offset

        rb.linearVelocity = throwDir.normalized * throwForce;
    }

    PhysicalWeapon to = heldObject.GetComponent<PhysicalWeapon>();
    if (to != null)
        to.MarkAsThrown();

    heldObject = null;
    currentWeapon = null;
}




IEnumerator SmoothEquip(GameObject obj)
{
    Vector3 startPos = obj.transform.localPosition;
    Quaternion startRot = obj.transform.localRotation;

    Vector3 targetPos = pickupPos;
    Quaternion targetRot = Quaternion.Euler(pickupRot);

    float duration = 0.15f;
    float t = 0f;

    while (t < duration)
    {
        float lerp = t / duration;
        obj.transform.localPosition = Vector3.Lerp(startPos, targetPos, lerp);
        obj.transform.localRotation = Quaternion.Slerp(startRot, targetRot, lerp);
        t += Time.deltaTime;
        yield return null;
    }

    obj.transform.localPosition = targetPos;
    obj.transform.localRotation = targetRot;
}


    // ============================================================
    // DROP (E ile bırakma - opsiyonel)
    // ============================================================

    void DropObject()
    {
        if (heldObject == null) return;

        Rigidbody rb = heldObject.GetComponent<Rigidbody>();
        heldObject.transform.SetParent(null);

        if (rb != null)
        {
            rb.isKinematic = false;
            rb.useGravity = true;
        }

        Collider col = heldObject.GetComponent<Collider>();
        if (col != null)
            col.enabled = true;

        heldObject = null;
        currentWeapon = null;
    }

    // ============================================================
    // Movement
    // ============================================================

    private void ApplyMovement()
    {
        Vector3 move = (transform.right * moveX + transform.forward * moveZ).normalized;
        float moveSpeed = crouching ? crouchSpeed : speed;
        cc.Move((move * moveSpeed + velocity) * Time.deltaTime);
    }

    private void HandleMovementAndAnimation()
    {
        if (animator != null)
        {
            animator.SetFloat("MoveX", moveX);
            animator.SetFloat("MoveY", moveZ);

            if (isGrounded)
                animator.SetBool("IsJumping", false);
        }
    }

    private void HandleJumpAndGravity()
    {
        isGrounded = cc.isGrounded;

        if (isGrounded && velocity.y < 0)
            velocity.y = -0.1f;

        if (Input.GetButtonDown("Jump") && isGrounded && !crouching)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);

            if (animator != null)
                animator.SetBool("IsJumping", true);
        }

        velocity.y += gravity * Time.deltaTime;
    }

    private void HandleCrouch()
    {
        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            crouching = !crouching;
            targetHeight = crouching ? crouchHeight : standHeight;
        }

        cc.height = Mathf.Lerp(cc.height, targetHeight, Time.deltaTime * crouchSmooth);
    }

    // ============================================================
    // Attack
    // ============================================================

    private void HandleAttackInput()
    {
        if (Input.GetMouseButtonDown(0) && animator != null && !isPerformingAttack && currentWeapon != null)
        {
            animator.SetTrigger("AttackTrigger");
        }
    }

   private void WeaponCheck()
{
    if (currentWeapon != null)
        currentWeapon.CheckMeleeHit(isPerformingAttack);
}


    public void StartAttackHitCheck()
    {
        isPerformingAttack = true;
    }

    public void EndAttackHitCheck()
{
    isPerformingAttack = false;
    currentWeapon?.CheckMeleeHit(false);
}

}
