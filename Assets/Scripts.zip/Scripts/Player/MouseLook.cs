using UnityEngine;

public class MouseLook : MonoBehaviour
{
    [Header("Settings")]
    public float sensitivity = 2f; // Örn. 2-5 arası bir değer

    [Header("Player Body")]
    public Transform playerBody;

    float xRot = 0f;

    void Start()
    {      
        if (playerBody == null)
        {
            Debug.LogError("[MouseLook] Player Body atanmadı! Lütfen Inspector'dan atayın.");
        }
    }

    void LateUpdate()
    {
    if (!GameManager.Instance.gameActive) return;
    float mouseX = Input.GetAxisRaw("Mouse X") * sensitivity; 
    float mouseY = Input.GetAxisRaw("Mouse Y") * sensitivity; 

    xRot -= mouseY;
    
    // Hata Kontrolü
    if (float.IsNaN(xRot) || float.IsInfinity(xRot))
    {
        xRot = 0f;
    }

    xRot = Mathf.Clamp(xRot, -85f, 85f);
    
    transform.localRotation = Quaternion.Euler(xRot, 0f, 0f);

    if (playerBody != null)
    {
        playerBody.Rotate(Vector3.up * mouseX);
    }
    else
    {
        Debug.LogError("[MouseLook] playerBody referansı Update içinde NULL!");
    }
}
}