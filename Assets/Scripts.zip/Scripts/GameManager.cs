using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Scene Settings")]
    public string gameSceneName = "SampleScene"; // Unity'deki sahne adını buraya yazın

    [Header("Game Settings")]
    public float gameDuration = 60f;
    private float timer;
    private int score;
    private int combo = 0;
    private float lastBasketTime = 0f;
    public float comboTimeout = 3f;
    public bool gameActive = false;

    void Awake()
    {
        // Singleton Yapısı + DontDestroyOnLoad
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // Sahne değişince bu obje yok olmasın
        }
        else
        {
            Destroy(gameObject); // Zaten bir tane varsa yenisini yok et
            return;
        }

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    void Update()
    {
        if (!gameActive) return;

        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            timer = 0;
            EndGame();
        }
        
        score = GetScore(); // Skoru güncelle

        if (score >= 1000)
        {
            EndGame();
        }   

    }

    // Bu fonksiyon butona tıklandığında çalışacak
    public void StartGame()
    {
        Debug.Log("Starting Game...");
        // 1. Önce Sahneyi Yükle
        SceneManager.LoadScene(gameSceneName);

        // 2. Sahne yüklendiğinde yapılacakları dinlemesi için bir olay (event) ekle
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    // Sahne yüklenmesi BİTTİĞİNDE bu fonksiyon otomatik çalışır
    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // Sadece oyun sahnesi ise başlat (Menüye dönünce çalışmasın diye kontrol)
        if (scene.name == gameSceneName)
        {
            InitializeGame();
        }

        // Olayı dinlemeyi bırak (Memory leak olmaması için)
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    // Oyun değişkenlerini başlatan asıl kısım burası
    private void InitializeGame()
    {
        score = 0;
        timer = gameDuration;
        combo = 0;
        gameActive = true;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        // UI Manager'ın o anki sahnede var olduğundan emin olmalıyız
        if (UIManager.Instance != null)
        {
            UIManager.Instance.ShowGameUI();
            UIManager.Instance.HideMenu();
            UIManager.Instance.HideGameOver();
        }
        else
        {
            Debug.LogWarning("UIManager bulunamadı! Sahneye UIManager eklediniz mi?");
        }
    }

    public void EndGame()
    {
        Debug.Log("Ending Game...");
        gameActive = false;
        
        if (UIManager.Instance != null)
            UIManager.Instance.ShowGameOver(score);
            
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        
    }

    public void AddScore(int amount)
    {
        if (!gameActive) return;

        score += amount;
        
        if (UIManager.Instance != null)
            UIManager.Instance.SpawnScorePopup(amount);
    }

    public void AddTime(float seconds)
    {
        if (!gameActive) return;
        timer += seconds;
    }

    public void OnBasketScored()
    {
        if (!gameActive) return; // Oyun bitmişse basket sayma

        float now = Time.time;

        if (now - lastBasketTime > comboTimeout)
            combo = 0;

        combo++;
        lastBasketTime = now;

        AddTime(5f);
        if (UIManager.Instance != null)
            UIManager.Instance.SpawnTimerPopup("+5s");

        if (combo == 3)
        {
            AddTime(10f);
            if (UIManager.Instance != null)
                UIManager.Instance.SpawnTimerPopup("COMBO +10s");
            combo = 0;
        }

        Debug.Log("Combo: " + combo);
    }

public void RestartGame()
{
    Debug.Log("Restarting Game...");

    Time.timeScale = 1; // Eğer oyun durdurulmuşsa zamanı tekrar başlat
    StartGame(); 
}

    public int GetScore() => score;
    public float GetRemainingTime() => timer;

    public void QuitGame()
    {
        Debug.Log("Quitting Game...");
        Application.Quit();
    }
}