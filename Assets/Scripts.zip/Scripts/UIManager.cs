using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Threading;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [Header("Main UI")]
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI timerText;

    [Header("Panels")]
    public GameObject menuPanel;
    public GameObject gameOverPanel;
    public GameObject gameUIPanel;

    [Header("Popup Score")]
    public GameObject popupPrefab;
    public Transform popupParent;

    [Header("Timer Popup")]
    public GameObject timerPopupPrefab;
    public Transform timerPopupParent;


    private bool isFlashing = false;

    void Awake()
    {
        Instance = this;
    }

    void Update()
    {
        if (!GameManager.Instance.gameActive) return;

        UpdateScore();
        UpdateTimer();
    }

    public void UpdateScore()
    {
        scoreText.text = "Score: " + GameManager.Instance.GetScore();
    }

    public void UpdateTimer()
    {
        float t = GameManager.Instance.GetRemainingTime();
        timerText.text = "Time: " + Mathf.Ceil(t);

        if (t <= 10 && !isFlashing)
            StartCoroutine(FlashTimer());
    }

    private System.Collections.IEnumerator FlashTimer()
    {
        isFlashing = true;
        Color normal = Color.yellow;
        Color red = Color.red;

        while (GameManager.Instance.GetRemainingTime() <= 10 && GameManager.Instance.gameActive)
        {
            timerText.color = red;
            yield return new WaitForSeconds(0.2f);

            timerText.color = normal;
            yield return new WaitForSeconds(0.2f);
        }

        timerText.color = normal;
        isFlashing = false;
    }

    public void SpawnScorePopup(int amount)
    {
        GameObject go = Instantiate(popupPrefab, popupParent);
        go.GetComponent<TextMeshProUGUI>().text = "+" + amount;
    }

    public void ShowGameOver(int finalScore)
    {
        gameOverPanel.SetActive(true);
        GameManager.Instance.gameActive = false;
        // Doğrusu:
        timerText.gameObject.SetActive(false);
        scoreText.gameObject.SetActive(false);
        gameOverPanel.transform.Find("FinalScore").GetComponent<TextMeshProUGUI>().text = "SCORE: " + finalScore;
    }

    public void HideGameOver() => gameOverPanel.SetActive(false);

    public void ShowGameUI() => gameUIPanel.SetActive(true);

    public void HideMenu() => menuPanel.SetActive(false);

    public void ShowMenu() => menuPanel.SetActive(true);

    public void SpawnTimerPopup(string text)
{
    GameObject go = Instantiate(timerPopupPrefab, timerPopupParent);
    go.GetComponent<TextMeshProUGUI>().text = text;
}

}
