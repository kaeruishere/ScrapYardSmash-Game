using UnityEngine;
using System;
using System.Collections;

public class BreakableHealth : MonoBehaviour
{
    [Header("Can Ayarları")]
    [SerializeField] private float maxHealth = 100f;

    [Header("Score Value")]
    public int scoreValue = 10; // obje kırınca kaç puan versin
    private float currentHealth;

    [Header("Kırılma Ayarları")]
    [SerializeField] private GameObject debrisRoot;
    [SerializeField] private float explosionPower = 2f;
    [SerializeField] private float explosionRadius = 1.5f;

 [Header("Physics Weight")]
    public float durabilityMultiplier = 1f; // ağır objeler daha dayanıklı olabilir



    private Rigidbody rb;
    private Rigidbody[] debrisPieces;

    public event Action<float, float> OnHealthChanged;
    public event Action OnDeath;

    void Awake()
    {
        currentHealth = maxHealth;
        rb = GetComponent<Rigidbody>();
    }

    void Start()
    {
        if (debrisRoot != null)
        {
            debrisRoot.SetActive(false);
            debrisPieces = debrisRoot.GetComponentsInChildren<Rigidbody>();
        }
    }

    // ============================================================
    public void TakeDamage(float dmg)
    {
        if (currentHealth <= 0) return;

        dmg *= durabilityMultiplier;   // ağırlığa göre dayanıklılık eklenebilir

        currentHealth -= dmg;
        currentHealth = Mathf.Max(0, currentHealth);

        OnHealthChanged?.Invoke(currentHealth, maxHealth);

        if (currentHealth <= 0)
            Die();
    }

    // ============================================================
    private void Die()
    {
        OnDeath?.Invoke();
        BreakApart();
    }

    // ============================================================


    private void BreakApart()
{
    if (debrisRoot == null)
    {
        Destroy(gameObject);
        return;
    }

    debrisRoot.SetActive(true);              // DebrisRoot açılır
    debrisRoot.transform.SetParent(null);    // Bağımsız hale gelir

    // Debug — doğru RB sayısını görelim
    Debug.Log("📦 DebrisPieces Count = " + debrisPieces.Length);
    foreach (var piece in debrisPieces)
    {
        Debug.Log("➡ RB: " + piece.name + " | kinematic=" + piece.isKinematic);
    }

    // Parçaları fırlat
    foreach (var piece in debrisPieces)
    {
        if (piece == null) continue;

        piece.isKinematic = false;   // Güvenlik — patlamadan önce kapalı olmasın

        if (rb != null)
        {
            piece.linearVelocity = rb.linearVelocity;
            piece.angularVelocity = rb.angularVelocity;
        }

        piece.AddExplosionForce(
            explosionPower,
            transform.position,
            explosionRadius,
            0.15f,
            ForceMode.Impulse
        );
    }
    
    GameManager.Instance.AddScore(scoreValue);
    Destroy(gameObject); 
}


    // ============================================================
    public void InitHealth(float newMaxHealth)
    {
        maxHealth = newMaxHealth;
        currentHealth = maxHealth;
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
    }
}
