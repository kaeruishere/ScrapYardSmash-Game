using System.Collections.Generic;
using UnityEngine;

public class PhysicalWeapon : MonoBehaviour
{
    [Header("Damage Settings")]
    public float baseDamage = 10f;
    public float otherDamageMultiplier = 1.0f;
    public float selfDamageMultiplier = 0.5f;

    [Header("Impact Thresholds")]
    public float minImpactSpeed = 1.0f;   // Bu hızın altındaysa damage YOK
    public float minImpactForce = 2.0f;   // Çok küçük çarpmalar için damage YOK

    [Header("Melee Settings")]
    public float hitCheckRadius = 0.6f;
    public LayerMask hitMask = ~0;
    public float pushForce = 10f;

    [Header("State")]
    public bool isThrown = false;
    private float ignoreCollisionTime = 0f;

    private Rigidbody rb;
    private HashSet<Collider> hitThisAttack = new HashSet<Collider>();

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (ignoreCollisionTime > 0f)
            ignoreCollisionTime -= Time.deltaTime;
    }

    // ============================================================
    //  THROW SYSTEM
    // ============================================================

    public void MarkAsThrown()
    {
        isThrown = true;
        ignoreCollisionTime = 0.12f;
         //Debug.Log($"🟦 [THROW] {name} thrown.");
    }

    public void ResetPickupState()
    {
        isThrown = false;
        ignoreCollisionTime = 0.12f;
        hitThisAttack.Clear();
         //Debug.Log($"🟪 [PICKUP] {name} picked up.");
    }

    // ============================================================
    //  COLLISION DAMAGE (THROWN)
    // ============================================================

    private void OnCollisionEnter(Collision collision)
    {
         //Debug.Log($"🟠 COLLISION: {name} → {collision.collider.name}");

        if (ignoreCollisionTime > 0f)
        {
             //Debug.Log("⏳ Collision ignored (ignoreCollisionTime)");
            return;
        }

        if (!isThrown)
        {
             //Debug.Log("🛑 Collision ignored (not thrown)");
            return;
        }

        float speed = rb.linearVelocity.magnitude;

        // ⭐ HIZ KONTROLÜ
        if (speed < minImpactSpeed)
        {
            //Debug.Log($"🟡 Too slow for damage. Speed = {speed:F2} (min {minImpactSpeed})");
            return;
        }

        float mass = rb.mass;
        float impactForce = speed * mass;

        // ⭐ FORCE KONTROLÜ
        if (impactForce < minImpactForce)
        {
             //Debug.Log($"🟡 Impact too small. Force = {impactForce:F2} (min {minImpactForce})");
            return;
        }

         //Debug.Log($"💥 Impact FORCE = {impactForce:F2}, SPEED = {speed:F2}");

        float outgoingDamage = baseDamage + impactForce * otherDamageMultiplier;
        float selfDamage = (baseDamage + impactForce) * selfDamageMultiplier;

        // TARGET DAMAGE
        BreakableHealth target = collision.collider.GetComponentInParent<BreakableHealth>();

        if (target != null)
        {
            Debug.Log($"🟥 TARGET DAMAGE → {outgoingDamage:F2}");
            target.TakeDamage(outgoingDamage);
        }

        // SELF DAMAGE
        BreakableHealth myHealth = GetComponent<BreakableHealth>();
        if (myHealth != null)
        {
            Debug.Log($"🟩 SELF DAMAGE → {selfDamage:F2}");
            myHealth.TakeDamage(selfDamage);
        }

        isThrown = false;
    }

    // ============================================================
    //  MELEE DAMAGE
    // ============================================================

    public void CheckMeleeHit(bool isAttacking)
    {
        if (!isAttacking)
        {
            hitThisAttack.Clear();
            return;
        }

        Collider[] hits = Physics.OverlapSphere(transform.position, hitCheckRadius, hitMask);

        foreach (Collider c in hits)
        {
            if (c.transform.IsChildOf(transform.root))
                continue;

            if (hitThisAttack.Contains(c))
                continue;

            ApplyMeleeDamage(c);
        }
    }

    private void ApplyMeleeDamage(Collider c)
    {
        BreakableHealth health = c.GetComponentInParent<BreakableHealth>();

        if (health == null)
            return;

         Debug.Log($"🔴 MELEE → {baseDamage} damage to {c.name}");

        health.TakeDamage(baseDamage);
        hitThisAttack.Add(c);

        Rigidbody targetRB = c.GetComponent<Rigidbody>();
        if (targetRB != null)
        {
            Vector3 dir = (c.transform.position - transform.position).normalized;
            targetRB.AddForce(dir * pushForce, ForceMode.Impulse);
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, hitCheckRadius);
    }
}
